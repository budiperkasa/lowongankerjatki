<?php
// Template Name: Register

get_template_part('tpl-login');
