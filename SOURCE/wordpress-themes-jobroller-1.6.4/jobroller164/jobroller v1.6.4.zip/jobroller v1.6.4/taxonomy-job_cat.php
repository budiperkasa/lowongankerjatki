<?php
	get_template_part('taxonomy-job');
