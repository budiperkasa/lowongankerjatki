<div id="footer">

    	<div class="inner">

			<p><?php _e('Copyright &copy;','appthemes'); ?> <?php echo date_i18n('Y'); ?></p>

		</div><!-- end inner -->

</div><!-- end footer -->
